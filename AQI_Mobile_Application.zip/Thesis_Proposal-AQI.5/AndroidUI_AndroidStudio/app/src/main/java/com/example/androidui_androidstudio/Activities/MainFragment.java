package com.example.androidui_androidstudio.Activities;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.PersistableBundle;
import android.widget.FrameLayout;

import com.example.androidui_androidstudio.R;
import com.google.android.material.tabs.TabLayout;
import android.view.LayoutInflater;

public class MainFragment extends AppCompatActivity{
    FrameLayout frameLayout;
    TabLayout tabLayout;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_main);
        frameLayout = (FrameLayout) findViewById(R.id.frameLayout);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, new WeatherFragment())
                .addToBackStack(null).commit();

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Fragment fragment = null;
                switch (tab.getPosition()){
                    case 0:
                        fragment = new WeatherFragment();
                        break;
                    case 1:
                        fragment = new HistoryFragment();
                        break;
                    case 2:
                        fragment = new NextDayFragment();
                        break;
                }
                Fragment effectiveFinalFragment = fragment;
                if(effectiveFinalFragment != null) {
                    updateUI(() -> getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, effectiveFinalFragment)
                            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN).commit());
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
    private void updateUI(Runnable action) {
        runOnUiThread(action);
    }
}