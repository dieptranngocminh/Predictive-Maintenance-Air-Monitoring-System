package com.example.androidui_androidstudio.Activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.androidui_androidstudio.R;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



public class HistoryFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    private DatabaseReference databaseReference;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        databaseReference = FirebaseDatabase.getInstance().getReference();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated( View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //setContentView(R.layout.fragment_history);

        // Initialize Firebase Database Reference
        databaseReference = FirebaseDatabase.getInstance().getReference();

        // Retrieve the latest temperature data
        retrieveLatestTemperatureData();
        retrieveLatestHumidityData();
        retrieveLatestPM10Data();
        retrieveLatestPM25Data();
        retrieveLatestSO2Data();
        retrieveLatestCOData();
        retrieveLatestCO2Data();
        retrieveLatestNO2Data();
        retrieveLatestO3Data();
    }

    private void setContentView(int fragmentHistory) {
    }

    private void retrieveLatestPM25Data() {
        if (getView() == null) return;
        DatabaseReference pm25Ref = databaseReference.child("airmonitoringV2").child("pm2_5_0001");
        LineChart lineChart = getView().findViewById(R.id.chartPM25);
        pm25Ref.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestPM25Data = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String pm25String = timeSnapshot.getValue(String.class);
                            try {
                                Float pm25Value = Float.parseFloat(pm25String);
                                latestPM25Data.put(time, pm25Value);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, pm25Value));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries, lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartPM25);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }

    private void retrieveLatestPM10Data() {
        if (getView() == null) return;
        DatabaseReference pm10Ref = databaseReference.child("airmonitoringV2").child("pm10_0001");
        LineChart lineChart = getView().findViewById(R.id.chartPM10);
        pm10Ref.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestPM10Data = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String pm10String = timeSnapshot.getValue(String.class);
                            try {
                                Float pm10Value = Float.parseFloat(pm10String);
                                latestPM10Data.put(time, pm10Value);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, pm10Value));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries, lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartPM10);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }

    private void retrieveLatestHumidityData() {
        if (getView() == null) return;
        DatabaseReference humidityRef = databaseReference.child("airmonitoringV2").child("humi_0001");
        LineChart lineChart = getView().findViewById(R.id.chartHumidity);
        humidityRef.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestHumidities = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String humidityString = timeSnapshot.getValue(String.class);
                            try {
                                Float humidity = Float.parseFloat(humidityString);
                                latestHumidities.put(time, humidity);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, humidity));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries,lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartHumidity);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }

    private void retrieveLatestTemperatureData() {
        if (getView() == null) return;
        DatabaseReference tempRef = databaseReference.child("airmonitoringV2").child("temp_0001");
        LineChart lineChart = getView().findViewById(R.id.chartTemperature);
        tempRef.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestTemperatures = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String temperatureString = timeSnapshot.getValue(String.class);
                            try {
                                Float temperature = Float.parseFloat(temperatureString);
                                latestTemperatures.put(time, temperature);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, temperature));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries,lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartTemperature);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }

    private void retrieveLatestSO2Data() {
        if (getView() == null) return;
        DatabaseReference so2Ref = databaseReference.child("airmonitoringV2").child("SO2_0001");
        LineChart lineChart = getView().findViewById(R.id.chartSO2);
        so2Ref.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestSO2 = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String SO2String = timeSnapshot.getValue(String.class);
                            try {
                                Float so2 = Float.parseFloat(SO2String);
                                latestSO2.put(time, so2);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, so2));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries,lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartSO2);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }

    private void retrieveLatestCOData() {
        if (getView() == null) return;
        DatabaseReference coRef = databaseReference.child("airmonitoringV2").child("CO_0001");
        LineChart lineChart = getView().findViewById(R.id.chartCO);
        coRef.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestCO = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String coString = timeSnapshot.getValue(String.class);
                            try {
                                Float co = Float.parseFloat(coString);
                                latestCO.put(time, co);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, co));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries,lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartCO);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }

    private void retrieveLatestCO2Data() {
        if (getView() == null) return;
        DatabaseReference co2Ref = databaseReference.child("airmonitoringV2").child("CO2_0001");
        LineChart lineChart = getView().findViewById(R.id.chartCO2);
        co2Ref.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestCO2 = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String co2String = timeSnapshot.getValue(String.class);
                            try {
                                Float co2 = Float.parseFloat(co2String);
                                latestCO2.put(time, co2);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, co2));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries,lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartCO2);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }

    private void retrieveLatestNO2Data() {
        if (getView() == null) return;
        DatabaseReference no2Ref = databaseReference.child("airmonitoringV2").child("NO2_0001");
        LineChart lineChart = getView().findViewById(R.id.chartNO2);
        no2Ref.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestNO2 = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String no2String = timeSnapshot.getValue(String.class);
                            try {
                                Float no2 = Float.parseFloat(no2String);
                                latestNO2.put(time, no2);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, no2));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries,lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartNO2);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }

    private void retrieveLatestO3Data() {
        if (getView() == null) return;
        DatabaseReference o3Ref = databaseReference.child("airmonitoringV2").child("O3_0001");
        LineChart lineChart = getView().findViewById(R.id.chartO3);
        o3Ref.orderByKey().limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Map<String, Float> latestO3 = new HashMap<>();
                    List<Entry> entries = new ArrayList<>();
                    List<String> times = new ArrayList<>();
                    int index = 0;

                    for (DataSnapshot dateSnapshot : dataSnapshot.getChildren()) {
                        for (DataSnapshot timeSnapshot : dateSnapshot.getChildren()) {
                            String time = timeSnapshot.getKey();
                            String o3String = timeSnapshot.getValue(String.class);
                            try {
                                Float o3 = Float.parseFloat(o3String);
                                latestO3.put(time, o3);
                                times.add(time); // This list will hold time strings like "00:05", "00:10", etc.
                                entries.add(new Entry(index, o3));
                                index++;
                            } catch (NumberFormatException e) {
                                // Handle the case where the string cannot be parsed as a float
                            }
                        }
                    }

                    // Update the chart on the main UI thread
                    //runOnUiThread(() -> updateChart(times, entries,lineChart));
                    if (isAdded()) { // Check if the fragment is currently added to its activity
                        getActivity().runOnUiThread(() -> {
                            LineChart lineChart = getView().findViewById(R.id.chartO3);
                            updateChart(times, entries, lineChart);
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle possible errors
            }
        });
    }



    private void updateChart(List<String> times, List<Entry> entries, LineChart lineChart) {
        // Calculate the maximum and minimum values from the entries
        float maxTemp = -Float.MAX_VALUE;
        float minTemp = Float.MAX_VALUE;
        for (Entry entry : entries) {
            maxTemp = Math.max(maxTemp, entry.getY());
            minTemp = Math.min(minTemp, entry.getY());
        }

        // Set the max and min for the Y-axis
        float yAxisMax = maxTemp + 1;
        float yAxisMin = minTemp - 1;

        // Prepare the entries for hourly data points
        List<Entry> hourlyEntries = new ArrayList<>();
        for (int i = 0; i < entries.size(); i++) {
            if(i == entries.size()-1 || i == 0) {
                hourlyEntries.add(entries.get(i));
            }
            else if(entries.get(i).getY() == maxTemp || entries.get(i).getY() == minTemp) {
                // Add entries that have maximum or minimum temperature
                hourlyEntries.add(entries.get(i));
            }
            else if(i%12 == 0){
                hourlyEntries.add(entries.get(i));
            }
            //Mark extreme value here
//            else {
//                float left = entries.get(i-1).getY();
//                float mid = entries.get(i).getY();
//                float right = entries.get(i+1).getY();
//                if(left<mid && mid > right || left>mid && mid < right) hourlyEntries.add(entries.get(i));
//            }
        }


        // Create the data set for all entries but disable the drawing of circles
        LineDataSet allDataSet = new LineDataSet(entries, "Temperature");
        allDataSet.setDrawCircles(false);
        allDataSet.setDrawValues(false); // Optionally disable the drawing of values
        allDataSet.setColor(Color.parseColor("#AA00FF"));

        // Customize the data set for hourly entries to draw circles
        LineDataSet hourlyDataSet = new LineDataSet(hourlyEntries, "Hourly Temperature");

        // Apply styling
        hourlyDataSet.setCircleColor(Color.parseColor("#AA00FF"));
        hourlyDataSet.setCircleRadius(6f);
        hourlyDataSet.setCircleHoleRadius(3f);
        hourlyDataSet.setDrawCircleHole(true);
        hourlyDataSet.setDrawCircles(true);
        hourlyDataSet.setDrawValues(true);
        hourlyDataSet.setLineWidth(0.2f);
        // Combine both data sets
        LineData data = new LineData();
        data.addDataSet(allDataSet);
        data.addDataSet(hourlyDataSet);

        // Set data to the chart
        lineChart.setData(data);

        // Customize the X Axis
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(times));
        xAxis.setGranularity(1f); // Only show labels for each entry
        xAxis.setDrawGridLines(false);
//        xAxis.setDrawAxisLine(false);
        xAxis.setTextColor(Color.GRAY);
        xAxis.setYOffset(10f); // Adjust this value to move the X-axis labels up or down

        // Customize the Y Axis (Left)
        YAxis leftAxis = lineChart.getAxisLeft();
        leftAxis.setDrawGridLines(true);
        leftAxis.setDrawAxisLine(false);
        leftAxis.setTextColor(Color.GRAY);
        leftAxis.setAxisMinimum(yAxisMin);
        leftAxis.setAxisMaximum(yAxisMax);
        leftAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format("%.1f", value);
            }
        });
        // Customize the Y Axis (Right)
        YAxis rightAxis = lineChart.getAxisRight();
        rightAxis.setEnabled(false);

        // Adjust the Legend position
        lineChart.getLegend().setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        lineChart.getLegend().setOrientation(Legend.LegendOrientation.HORIZONTAL);
        lineChart.getLegend().setDrawInside(false);
        lineChart.getLegend().setYOffset(5f); // Adjust this value to move the legend up or down

        // Adjust extra bottom offset to make space for X-axis labels and legend
        lineChart.setExtraBottomOffset(10f);

        // Other customizations like axis colors, line width, etc., remain the same...
        lineChart.getDescription().setEnabled(false);        // Remove description label

        // Refresh the chart

        lineChart.invalidate();
    }

    private void runOnUiThread() {
        if (isAdded()) {
            getActivity().runOnUiThread(() -> {
                // update your UI component here
            });
        }
    }







}