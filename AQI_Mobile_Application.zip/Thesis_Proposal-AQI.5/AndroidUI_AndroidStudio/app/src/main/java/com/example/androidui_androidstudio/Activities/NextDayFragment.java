package com.example.androidui_androidstudio.Activities;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.androidui_androidstudio.R;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.androidui_androidstudio.Activities.Dashboard_main;
import com.example.androidui_androidstudio.Activities.FutureActivity;
import com.example.androidui_androidstudio.Activities.HistoryPage;
import com.example.androidui_androidstudio.Adapters.HourlyAdapters;
import com.example.androidui_androidstudio.Domains.Hourly;
import com.example.androidui_androidstudio.MQTTHelper;
import com.example.androidui_androidstudio.PermissionHelper;
import com.example.androidui_androidstudio.R;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
public class NextDayFragment extends Fragment {


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_next_day, container, false);
        LinearLayout nextDaysContainer = rootView.findViewById(R.id.nextDaysContainer);

        String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "Mon"};
        int[] temperatures = {25, 24, 24, 24, 24, 25, 26, 26, 26};
        String[] conditions = {"cloudy", "rainy", "cloudy", "cloudy", "cloudy", "rainy", "sunny", "cloudy", "sunny"};
        int[] rainChances = {50, 70, 45, 50, 45, 45, 0, 50, 0};

        for (int i = 0; i < days.length; i++) {
            View dayView = inflater.inflate(R.layout.weather_day_item, null);
            TextView dayName = dayView.findViewById(R.id.dayName);
            ImageView weatherIcon = dayView.findViewById(R.id.weatherIcon);
            TextView tempView = dayView.findViewById(R.id.temperature);
            TextView rainChance = dayView.findViewById(R.id.rainChance);

            dayName.setText(days[i]);
            tempView.setText(temperatures[i] + "°C");
            rainChance.setText(rainChances[i] + "%");

            int drawableResourceId = this.getResources().getIdentifier("drawable/" + conditions[i], null, this.getContext().getPackageName());
            weatherIcon.setImageResource(drawableResourceId);

            nextDaysContainer.addView(dayView);
        }

        return rootView;
    }
    private void fetchWeatherForecast() {
        String url = "https://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={API_KEY}";
        // Gửi yêu cầu và xử lý phản hồi để cập nhật UI
    }


//    private void initRecycleViews(View rootView) {
//        ArrayList<Hourly> items = new ArrayList<>();
//        items.add(new Hourly("09 am", 27, "cloudy"));
//        items.add(new Hourly("10 am", 29, "sunny"));
//        items.add(new Hourly("11 am", 31, "sunny"));
//        items.add(new Hourly("12 am", 31, "sunny"));
//        items.add(new Hourly("01 pm", 32, "sunny"));
//        items.add(new Hourly("02 pm", 33, "sunny"));
//        items.add(new Hourly("03 pm", 32, "wind"));
//        items.add(new Hourly("04 pm", 32, "cloudy"));
//        items.add(new Hourly("05 pm", 31, "cloudy"));
//
//        RecyclerView recyclerView = rootView.findViewById(R.id.view1);
//        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
//        RecyclerView.Adapter<HourlyAdapters.viewholder> adapterHourly = new HourlyAdapters(items);
//        recyclerView.setAdapter(adapterHourly);
//    }
}