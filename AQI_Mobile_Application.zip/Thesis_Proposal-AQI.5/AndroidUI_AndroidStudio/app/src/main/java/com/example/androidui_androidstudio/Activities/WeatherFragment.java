package com.example.androidui_androidstudio.Activities;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.androidui_androidstudio.Activities.Dashboard_main;
import com.example.androidui_androidstudio.Activities.FutureActivity;
import com.example.androidui_androidstudio.Activities.HistoryPage;
import com.example.androidui_androidstudio.Adapters.HourlyAdapters;
import com.example.androidui_androidstudio.Domains.Hourly;
import com.example.androidui_androidstudio.MQTTHelper;
import com.example.androidui_androidstudio.PermissionHelper;
import com.example.androidui_androidstudio.R;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


public class WeatherFragment extends Fragment {


    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable runnable;

    // For weather API
    private TextView txtWeatherStatus, txtAQI, txtCity, txtAdvice, txtAirPressure;
    private TextView txtTemperature, txtHumidity, txtPM25, txtPM10, txtSO2, txtNO2, txtO3, txtCO, txtAQItimestamp, txtAQIValue;
    private ImageView imgWeatherStatus;
    private SharedPreferences sharedPreferences;
    private MQTTHelper mqttHelper;
    private String MQTT_Payload;

/*    public DashboardFragment() {
        // Required empty public constructor
    }*/

    @Override

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_weather, container, false);

        PermissionHelper.LoopcheckNetworkConnection(requireContext());
        PermissionHelper.checkGPSPermission(requireContext());

        if (rootView == null) {
            Log.d("WeatherFragment", "rootView is null");
            return null;
        }
        runnable = new Runnable() {
            @Override
            public void run() {
                updateCurrentTime();
                weatherRun();
                handler.postDelayed(this, 10000); // updates every minute
            }
        };
        // Start the initial runnable task by posting through the handler
        handler.post(runnable);
        initRecycleViews(rootView);
        startMQTT();

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        return rootView;
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(runnable); // stop the handler when fragment not visible
    }

    @Override
    public void onResume() {
        super.onResume();
        PermissionHelper.LoopcheckNetworkConnection(requireContext());
        handler.post(runnable); // restart the handler when fragment is visible again
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = getActivity().getSharedPreferences("YourPreferenceFile", Context.MODE_PRIVATE);
    }



    public void startMQTT() {
        mqttHelper = new MQTTHelper(requireContext());
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconnect, String serverURI) {
                Log.d("mqtt_log", "Connected!");
            }
            @Override
            public void connectionLost(Throwable cause) {
                Log.d("mqtt_log", "Connection lost...");
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.d("mqtt_log", "Message arrived at topic: " + topic + "; Payload: " + message.toString());
                MQTT_Payload = message.toString();
                updateAQIValue();
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.d("mqtt_log", "Delivery Success!");
            }
        });
    }

    public void updateAQIValue() {
        if (getView() == null) return; // Fragment's view is not yet created
        txtTemperature = getView().findViewById(R.id.textViewTemperature);
        txtHumidity = getView().findViewById(R.id.textViewHumidity);
        txtPM25 = getView().findViewById(R.id.textViewPM25);
        txtPM10 = getView().findViewById(R.id.textViewPM10);
        txtSO2 = getView().findViewById(R.id.textViewSO2);
        txtNO2 = getView().findViewById(R.id.textViewNO2);
        txtO3 = getView().findViewById(R.id.textViewO3);
        txtCO = getView().findViewById(R.id.textViewCO);
        txtAQItimestamp = getView().findViewById(R.id.textViewAQI_timestamp);
        txtAQIValue = getView().findViewById(R.id.AQIValue);
        txtAirPressure = getView().findViewById(R.id.textViewAirPressure);

        try {
            // Parse chuỗi JSON thành đối tượng JSON
            JSONObject jsonPayload = new JSONObject(MQTT_Payload);
            // Lấy danh sách các cảm biến
            JSONArray sensors = jsonPayload.getJSONArray("sensors");

            // Duyệt qua danh sách cảm biến để lấy các giá trị cần thiết
            for (int i = 0; i < sensors.length(); i++) {
                JSONObject sensor = sensors.getJSONObject(i);
                String sensorName = sensor.getString("sensor_name");
                String sensorValue = sensor.getString("sensor_value");
                // Lấy thời gian từ chuỗi JSON
                String timestamp = jsonPayload.getString("timestamp");
                // Set giá trị cho biến txtAQItimestamp
                txtAQItimestamp.setText("Lasted update at " + timestamp);
                // Cập nhật TextView dựa trên tên cảm biến
                switch (sensorName) {
                    case "temp_0002":
                        txtTemperature.setText(sensorValue);
                        break;
                    case "humi_0002":
                        txtHumidity.setText(sensorValue);
                        break;
                    case "pm2_5_0001":
                        txtPM25.setText(sensorValue);
                        break;
                    case "pm10_0001":
                        txtPM10.setText(sensorValue);
                        break;
                    case "SO2_0001":
                        txtSO2.setText(sensorValue);
                        break;
                    case "NO2_0001":
                        txtNO2.setText(sensorValue);
                        break;
                    case "O3_0001":
                        txtO3.setText(sensorValue);
                        break;
                    case "CO_0001":
                        txtCO.setText(sensorValue);
                        break;
                    case "AQI":
                        txtAQIValue.setText(sensorValue);
                        
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void initRecycleViews(View rootView) {
        // Initialize any RecyclerViews here
    }

/*    private void updateCurrentTime() {
        // Update current time if needed
    }*/

    private void weatherRun() {
        if (getView() == null) return; // Fragment's view is not yet created
        txtWeatherStatus = getView().findViewById(R.id.textViewWeatherStatus);
        txtAQI = getView().findViewById(R.id.textViewAQI);
        txtCity = getView().findViewById(R.id.textViewCity);
        txtAdvice = getView().findViewById(R.id.textViewAdvice);
        imgWeatherStatus = getView().findViewById(R.id.imageViewWeatherStatus);
        txtAirPressure = getView().findViewById(R.id.textViewAirPressure);

        // Asking for permission and get the lat + long value
        getCurrentLocation();

        float latitude = sharedPreferences.getFloat("Latitude", 0.0f); // 0.0f is the default value
        float longitude = sharedPreferences.getFloat("Longitude", 0.0f);
        if (latitude == 0.0f || longitude == 0.0f) return;
        String APIKEY = "a1d63f18c12b440415" + "d0791d25cea7e4";
        String url = "https://api.openweathermap.org/data/2.5/weather?lat="
                + latitude
                + "&lon=" + longitude
                + "&appid=" + APIKEY
                + "&units=metric";
        RequestQueue requestQueue = Volley.newRequestQueue(requireContext());
        @SuppressLint("SetTextI18n") StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    Log.d("Testing_log", "Result for current weather:" + response);
                    try {
                        //JSONObject for result
                        JSONObject jsonObject_respone = new JSONObject(response);
                        //Set city name
                        txtCity.setText(jsonObject_respone.getString("name"));
                        //Set weather
                        JSONArray jsonArray_weather = jsonObject_respone.getJSONArray("weather");
                        JSONObject jsonObject_weather = jsonArray_weather.getJSONObject(0);
                        txtWeatherStatus.setText(capitalizeFirstLetterOfEachWord(
                                        jsonObject_weather.getString("description")
                                )
                        );
//                        //Update icon
                        String icon = jsonObject_weather.getString("icon");
                        String resourceName = "img" + icon; // Assuming icon has values like "01d", "02d"...
                        int resourceId = getResources().getIdentifier(resourceName, "drawable", requireActivity().getPackageName());
                        imgWeatherStatus.setImageResource(resourceId);

                        //Set air pressure
                        JSONObject jsonObject_main = jsonObject_respone.getJSONObject("main");
                        txtAirPressure.setText(jsonObject_main.getString("pressure") + " pHa");

                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                }
                , error -> {
            Log.d("Testing_log", "FAILED TO REQUEST GET ON URL!!! ERROR:" + error);
        });
        requestQueue.add(stringRequest);
    }

    @SuppressLint({"MissingPermission", "VisibleForTests"})
    private void getCurrentLocation() {
        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(3000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationServices.getFusedLocationProviderClient(requireContext())
                .requestLocationUpdates(locationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {
                        super.onLocationResult(locationResult);
                        LocationServices.getFusedLocationProviderClient(requireContext())
                                .removeLocationUpdates(this);
                        if (locationResult != null && locationResult.getLocations().size() > 0) {
                            int lastLocationIndex = locationResult.getLocations().size() - 1;
                            double latitude = locationResult.getLocations().get(lastLocationIndex).getLatitude();
                            double longitude = locationResult.getLocations().get(lastLocationIndex).getLongitude();
                            // Saving the location data
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putFloat("Latitude", (float) latitude);
                            editor.putFloat("Longitude", (float) longitude);
                            editor.apply();
                        }
                    }
                }, Looper.getMainLooper());
    }

    private void updateCurrentTime() {
        if (getView() == null) return; // Fragment's view is not yet created
        TextView textViewTime = getView().findViewById(R.id.textViewTime); // Make sure you have a TextView with the id value_time in your layout
        Calendar calendar = Calendar.getInstance();
        TimeZone tz = TimeZone.getTimeZone("Asia/Ho_Chi_Minh");
        calendar.setTimeZone(tz);

        SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd '|' hh:mm a", Locale.ENGLISH);
        sdf.setTimeZone(tz);

        String currentTime = sdf.format(calendar.getTime());
        textViewTime.setText(currentTime);
    }

    public String capitalizeFirstLetterOfEachWord(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        StringBuilder capitalizedString = new StringBuilder();
        String[] words = input.split(" ");
        for (String word : words) {
            String firstLetter = word.substring(0, 1).toUpperCase();
            String remainingLetters = word.substring(1).toLowerCase();
            capitalizedString.append(firstLetter).append(remainingLetters).append(" ");
        }

        return capitalizedString.toString().trim(); // trim to remove the last unnecessary space
    }
}